// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCrsk8S9Ezgkhuh9Cog1jgO9QyNJksAG_Q",
  authDomain: "sadakat-web.firebaseapp.com",
  projectId: "sadakat-web",
  storageBucket: "sadakat-web.firebasestorage.app",
  messagingSenderId: "944454128472",
  appId: "1:944454128472:web:2e1406378201c2a3288b2d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);